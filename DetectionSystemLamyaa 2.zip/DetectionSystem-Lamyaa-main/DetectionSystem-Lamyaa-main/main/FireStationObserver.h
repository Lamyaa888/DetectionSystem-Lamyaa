#ifndef FIRESTATIONOBSERVER_H
#define FIRESTATIONOBSERVER_H

#include "Observer.h"

class FireStationObserver : public Observer {
public:
    void update() override {
        // simulate calling fire station
    }
};

#endif
