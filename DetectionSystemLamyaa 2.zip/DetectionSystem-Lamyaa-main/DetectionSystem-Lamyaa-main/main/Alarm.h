#ifndef ALARM_H
#define ALARM_H

#include "Observer.h"

class Alarm : public Observer {
public:
    bool isTriggered;

    Alarm() : isTriggered(false) {}

    void update() override {
        isTriggered = true;
    }

    void reset() {
        isTriggered = false;
    }
};

#endif
